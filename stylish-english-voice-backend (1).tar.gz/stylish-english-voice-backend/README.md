# Stylish English — Voice Backend (Vercel)

## 📁 Project Structure
```
stylish-english-voice-backend/
├── api/
│   ├── voice-session.js    ← Main AI proxy endpoint
│   └── health.js           ← Health check
├── vercel.json             ← Vercel configuration
├── package.json            ← Dependencies
└── README.md               ← This file
```

## 🚀 Deployment Steps

### 1. Install Vercel CLI
```bash
npm i -g vercel
```

### 2. Set API Key (secure, never in code)
```bash
vercel secrets add gemini-api-key "YOUR_GOOGLE_GEMINI_API_KEY"
```

### 3. Deploy
```bash
cd stylish-english-voice-backend
vercel --prod
```

### 4. Connect Frontend
After deployment, you'll get a URL like:
`https://stylish-english-voice.vercel.app`

In the HTML file, find this line in the Voice FAB script:
```js
var VF_WS_URL = null;
```
Replace with:
```js
var VF_WS_URL = 'https://stylish-english-voice.vercel.app/api/voice-session';
```

## 🔒 Security
- API key is stored as a Vercel Secret (server-side only)
- Never exposed to the browser
- CORS enabled for your domain

## 📡 API Usage

### POST /api/voice-session
```json
{
  "text": "Hello, my name is Ahmed",
  "age": "adult",
  "history": [
    { "role": "user", "parts": [{ "text": "Hi" }] },
    { "role": "model", "parts": [{ "text": "Hello!" }] }
  ]
}
```

### Response
```json
{
  "reply": "Great pronunciation! Now try saying...",
  "age": "adult"
}
```

### GET /api/health
Returns server status.
